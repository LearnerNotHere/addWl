<?php

//                __                            _
//               / _| ___  _ __ _ __   ___  ___(_) __ _
//              | |_ / _ \| '__| '_ \ / _ \/ __| |/ _` |
//              |  _| (_) | |  | | | |  __/\__ \ | (_| |
//              |_|  \___/|_|  |_| |_|\___||___/_|\__,_|
//              Config Files - https://www.fornesia.com
//
$agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0';
$cookie = 'source=1392610;_ga=GA1.2.1319722324.1637472514;_gid=GA1.2.461919432.1637472514;__auc=e962c5e417d40f7be467c50567c;session_token=db10f19c7bf8325f3e409f5ee36c0bc38e1c7b5543dc1f5d24fb471e19d46751;faucetpay=dee5brtsbs2nhof2t950atqj4g;remember_me=2288825%3A027d9a95993ef796e7fcb40bf21b5a228441d4855de4f27c0c18cd227116f334%3A391a2bf26425f4c687741a2435c603faa869fe59441bd8d1cf552e8f3180a4d4;__asc=5bd4dbeb17d49f30b1b9ba845e8;_gat_gtag_UA_154633790_1=1;sc_is_visitor_unique=rx12149426.1637624226.754D397233554FE41EAA45DF1339CB2A.20.13.7.6.5.5.4.4.4';

# 1 Bitcoin
# 2 Ethereum
# 4 Dogecoin
# 5 Litecoin
# 6 Bitcoin Cash
# 7 Dash
# 8 DigiByte
# 9 Tron
# 10 Tether
# 11 Feyorra
# 12 Zcash
# 13 Binance BNB

$coin = '9';
